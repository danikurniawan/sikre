# Bootstrap-Confirmation

[![Bower version](https://img.shields.io/bower/v/bootstrap-confirmation2.svg?style=flat-square)](http://mistic100.github.io/Bootstrap-Confirmation)

Bootstrap plugin for on-place confirm boxes using Popover.


## Documentation

http://mistic100.github.io/Bootstrap-Confirmation


## Changes from original one

- Bootstrap 3 compatible
- Fix double event fires
- Automatic handle of links (without need of custom callback)
